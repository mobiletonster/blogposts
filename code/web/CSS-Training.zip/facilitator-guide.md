# CSS 101: Facilitator Guide

**Length:** 90 min of CSS, then 30 min of design reviews
**Audience:** C# developers who are new to CSS
**Format:** Everyone builds the same page, live, one step at a time

---

## How the files fit together

```
CSS-Training/
├── monsters-start.html      ← the page everyone opens. It links to styles.css
├── styles.css               ← empty. This is the file we build together
├── monsters-finished.html   ← the same HTML, linked to checkpoints/step-4.css
├── images/                  ← one SVG avatar per monster
└── checkpoints/
    ├── step-1.css           ← variables + base
    ├── step-2.css           ← + box model (cards become boxes)
    ├── step-3.css           ← + layout (Flexbox header, Grid cards)
    └── step-4.css           ← + hover, transitions, animations = the finished page
```

**The workflow:** open `monsters-start.html` in the browser and `styles.css` in VS Code. Type CSS, save, and refresh the browser. Each **Build** box below says what to add to `styles.css`.

**If someone falls behind:** they copy the matching checkpoint over their `styles.css`, refresh, and they're caught up. Each checkpoint contains everything up to that step, so `step-4.css` matches the finished page.

**DevTools is for experimenting.** Changes made there disappear when you refresh. Anything you want to keep goes into `styles.css`.

**The games are scratch work.** Selector Golf runs in the console. For Specificity Showdown, paste rules into a `<style>` block in DevTools, or at the bottom of `styles.css`, and delete them when the round is over.

## Before the session

- [ ] Send everyone the whole folder, including `images/` and `checkpoints/` (zip it). They need VS Code and Chrome or Edge.
- [ ] Bump your editor and DevTools font size to 150% or more.
- [ ] Open `monsters-finished.html` in a second tab.
- [ ] Have a timer ready for the Style-Off.

---

## Run of show

### 0:00 — Hook and the bare page (8 min)

1. Show `monsters-finished.html` and click **Lights out**.
2. Open `monsters-start.html`. Say: "Same HTML. Open both files and you'll see only one line in the `<head>` is different. Everything else is CSS."
3. Open DevTools and select the `<h1>` in the Elements panel. Point out the rules labeled **user agent stylesheet**. The browser ships with default styles, which is why headings are big and lists have bullets.
4. In the Console:
   ```js
   $0                               // the element selected in the Elements panel
   getComputedStyle($0).fontSize    // the value the browser actually used
   document.designMode = "on"       // fun: the whole page is editable text ("off" to stop)
   ```

### 0:08 — Selectors are queries (20 min)

**Key idea:** CSS selectors and `querySelectorAll` use the same language. If you can query an element, you can style it.

**C# analogy:** a selector works like LINQ over a tree. `.card[data-status="sleeping"] h3` reads like `monsters.Where(m => m.Status == Sleeping).Select(m => m.Name)`.

Everyone pastes this helper into their console:

```js
const hl  = s => { clr(); $$(s).forEach(e => e.style.outline = '3px solid hotpink'); return $$(s).length; };
const clr = () => $$('*').forEach(e => e.style.outline = '');
```

Then demo:

```js
hl('h3')                          // type
hl('.card')                       // class
hl('#roster')                     // id
hl('[data-status="sleeping"]')    // attribute
hl('.card h3')                    // descendant (any depth)
hl('nav > ul > li')               // child (exactly one level)
```

`$$()` is DevTools shorthand for `document.querySelectorAll()`. Show the long form once so people recognize it in real code.

#### Game: Selector Golf (about 10 min)

Read out the target. The shortest selector that matches **exactly** those elements wins. `hl()` returns the count, so players can check their own answers.

| # | Target | Count | Par answer | Notes |
|---|---|---|---|---|
| 1 | All the monster cards | 6 | `.card` | Warm-up. |
| 2 | Only the sleeping monsters | 2 | `[data-status=sleeping]` | The quotes are optional for simple values. |
| 3 | Only the nav links | 4 | `nav a` | |
| 4 | Every other card | 3 | `.card:nth-child(2n)` | **Gotcha:** `li:nth-child(2n)` matches 11 elements. It also catches nav items and the "Fears" lines, because they're `li`s too. The modern fix is `:nth-child(2n of .card)`, which counts only the elements that match `.card`. |
| 5 | Vampires that are sleeping | 1 | `[data-type=vampire][data-status=sleeping]` | Stacked selectors with no space mean AND. |
| 6 | Monsters with low scare power | 2 | `.card:has(.low)` | A "parent selector". Most people don't know it exists. |
| 7 | Every monster that isn't a vampire | 4 | `.card:not([data-type=vampire])` | |
| 8 | The "Fears" line on each card | 6 | `.meta li:last-child` | **Gotcha:** `li:last-child` matches 8. It also catches the last nav link and Mumbling Mort's whole card. |
| Bonus | The avatars of both vampires | 2 | `[data-type=vampire] img` | A descendant selector on top of an attribute selector. |
| Bonus 2 | Every other *lurking* monster (Count Vladimir and Howling Hank) | 2 | `:nth-child(odd of [data-status=lurking])` | Plain `:nth-child` can't do this, because it counts every sibling. `of` counts only the lurking ones. |

Every answer above was checked against the page.

**Takeaway:** a selector that's too broad hits things you didn't mean, just like an over-eager LINQ `Where`. Be specific about what you mean.

### 0:28 — Cascade and specificity (10 min)

**Key idea:** when two rules target the same element, the browser picks a winner. It checks these in order:

1. `!important`
2. Specificity
3. Source order (the later rule wins)

**Analogies:**

- **Cascade ≈ ASP.NET config layering.** Values in `appsettings.json` get overridden by `appsettings.Development.json`, and environment variables override both.
- **Specificity ≈ comparing version numbers.** Count the selector as (IDs . classes . elements). `1.0.0` beats `0.9.9`, so one ID beats any number of classes.

#### Game: Specificity Showdown (about 7 min)

Paste each pair, have the room vote with a show of hands, then reveal the result. Inspect the element so everyone can see the losing rule crossed out in the Styles pane. Delete the pair before the next round.

| Round | Paste this | Inspect | Winner | Why |
|---|---|---|---|---|
| 1 | `.card h3 { color: blue }`<br>`h3 { color: red }` | any monster name | **blue** | 0.1.1 beats 0.0.1. Coming later doesn't help red. |
| 2 | `#roster .card { border: 3px solid red }`<br>`.roster .card.featured { border: 3px solid green }` | Count Vladimir | **red** | 1.1.0 beats 0.3.0. One ID beats three classes. |
| 3 | `.badge { color: red }`<br>`.badge { color: green }` | any badge | **green** | The specificity is tied, so the later rule wins. |
| 4 (gotcha) | `body { color: green }`<br>`* { color: purple }` | any monster name | **purple** | `*` has zero specificity, but it matches the `h3` directly. An inherited value always loses to a direct match. |
| Bonus | `main h3 { color: red }`<br>`h3 { color: blue !important }` | any monster name | **blue** | `!important` jumps the queue. Treat it like `#pragma warning disable`: legal, but every use deserves a review comment. |

Every winner above was checked in Chromium.

**Teaser (1 min): `@layer`, the modern fix for specificity fights.** Paste this:

```css
@layer base { #roster h3 { color: red } }
h3 { color: blue }
```

**Blue** wins, even though red has an ID. Styles outside a layer beat styles inside one, whatever the specificity. Teams use layers like `@layer reset, base, components, utilities` so that order is decided on purpose instead of by specificity fights or `!important`.

### 0:38 — Variables, base styles and the box model (12 min)

> **Build: STEP 1** (checkpoint `step-1.css`)
> Add `color-scheme` and the `:root` variables, the one-line `body.dark` rule, and the `body` and heading rules.
> **Afterwards:** a nicer font and a faint purple background. Still a plain document.

Explain `:root { --accent: … }` and `var(--accent)` briefly. Then explain `light-dark(#f6f3f9, #120d18)`: each color is written **once**, with its light and dark values side by side. The browser picks one based on `color-scheme`, so `body.dark { color-scheme: dark }` is the whole dark theme. Leave it at that for now. The payoff comes in STEP 4.

*Old way, for comparison:* repeat every variable inside a `body.dark { … }` block, or inside `@media (prefers-color-scheme: dark)`. That means two lists of colors to keep in sync.

Next, show that every element is a box. Paste `* { outline: 1px solid red }` as scratch, look around, then delete it. Select a card and point to the box diagram at the bottom of the Styles pane.

> **Build: STEP 2** (checkpoint `step-2.css`)
> Add `box-sizing: border-box`, the `main` width, the list resets, the three `[data-status]` rules that each set `--status`, then `.card`, `.badge` and `.avatar`.
> **Afterwards:** each monster is a card with a small round avatar, a colored edge and a status badge, stacked in one column. Banished monsters go grayscale with `filter: grayscale(1)`.

Point out that the status colors come from **attribute selectors**, the same ones from Selector Golf. Each status sets **one** variable, `--status`, and the card border, badge and avatar ring all read it with `var(--status, var(--muted))`. The second value is a fallback, like `??` in C#. Adding a new status later takes one line.

Two quick points about the avatars:

- In the bare page they render at 120px because of the `width` and `height` attributes in the HTML. CSS overrides those attributes, so `.avatar { width: 72px }` wins. That's the cascade again.
- `border-radius: 50%` turns a square box into a circle. Try `20%` live to show the difference.

### 0:50 — Layout: Flexbox and Grid (17 min)

**Rule of thumb:** use Flexbox for one direction (a row *or* a column). Use Grid for two dimensions (rows *and* columns).

> **Build: STEP 3, the header** (Flexbox)
> Build it up one line at a time, saving after each:
> 1. `#site-header { display: flex }`: everything jumps into a row.
> 2. Add `align-items: center; gap: 1.5rem;` and the colors.
> 3. Add `nav { margin-left: auto }`. Ask: "Why does that push the nav to the right?" Because an `auto` margin soaks up the free space.
> 4. Add the `nav ul` and `nav a` rules to make the links horizontal.

> **Build: STEP 3, the cards** (Grid)
> 1. Add `.roster { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem }`.
> 2. Swap the columns for `repeat(auto-fill, minmax(240px, 1fr))` and resize the window. The layout is responsive with no media query.
> 3. Add `.card { margin-bottom: 0 }`, because the grid gap handles spacing now. (`gap` is the modern replacement for margins plus `:last-child` exceptions.)
> 4. Add `.card.featured { grid-column: span 2 }`.
> **Afterwards (checkpoint `step-3.css`):** it looks like a real app.

In DevTools, the **flex** and **grid** badges next to an element turn on a layout overlay. Show both.

### 1:07 — Making it feel alive (8 min)

1. In the Console:
   ```js
   document.body.classList.toggle('dark')
   ```
   Dark mode already works, because STEP 1 wrote every color with `light-dark()` and `body.dark` switches `color-scheme`. This is the payoff of the JS–CSS link: **JS changes state (a class), and CSS decides how that state looks.** The **Lights out** button runs exactly this line.

> **Build: STEP 4** (checkpoint `step-4.css`)
> Add the `body` transition, the `:focus-visible` ring, the button styles, the card `:hover` lift, the avatar wobble, the `glow` and `snore` keyframes, and the two media queries at the bottom.
> **Afterwards:** this matches `monsters-finished.html`. Cards lift and avatars wobble on hover, Lurking badges glow, Sleeping badges snore, and the theme fades.

Four modern techniques are worth pointing out as you build this step:

- **Individual transform properties.** Use `translate: 0 -4px`, `rotate: -8deg` and `scale: 1.08` instead of one `transform: translateY(-4px) rotate(-8deg) scale(1.08)` string. Each one can be transitioned and overridden separately, like separate properties on a C# object instead of one formatted string.
- **`:focus-visible`.** Press **Tab** through the nav to show the orange focus ring, then click a link with the mouse to show that no ring appears. The old `:focus` showed the ring on mouse clicks too, which is why people used to remove focus styles altogether. That breaks the page for keyboard users.
- **Media query range syntax.** Write `@media (width <= 560px)` instead of `@media (max-width: 560px)`. It reads like a C# comparison.
- **`prefers-reduced-motion`.** Animations that loop forever can make some people feel ill. This block turns them off when the OS "reduce motion" setting is on. To demo it, go to DevTools → Ctrl+Shift+P → "Emulate CSS prefers-reduced-motion" and watch the glow and snore stop. Note that it needs no `!important`, because the selectors match the specificity of the original rules and the block comes later in the file.

Point out the selector `.card:hover .avatar`. You hover one element (the card) and style another (the avatar). The glow color is `color-mix(in srgb, var(--status) 60%, transparent)`: it reuses the status color with 40% transparency instead of hard-coding an `rgb()` value.

Teaser: "Animations deserve their own session."

### 1:15 — Mini Style-Off (10 min)

- Pairs start from a **blank** `styles.css` (save a copy of their work first) and get **7 minutes**.
- Rules: CSS only, and no changes to the HTML.
- Spend **3 minutes** on a gallery walk or screen-share, then vote on two prizes: *Most Polished* and *Most Chaotic*.
- If you're short on time, cut this segment and give the 10 minutes to design reviews.

### 1:25 — Wrap-up (5 min)

How this maps to Blazor:

- `Component.razor.css` is **scoped**. Blazor rewrites your selectors with a unique attribute, like `h3[b-x7k2...]`, so styles can't leak out of the component.
- `::deep` lets a parent component's scoped styles reach into child components.
- Put shared design tokens (CSS variables) in `app.css` under `:root`, the same as STEP 1.
- For the next session: native CSS nesting (`.card { & h3 { } }` with no Sass needed) and `@scope`. Both are good fits for component styles. Browse [modern-css.com](https://modern-css.com/category/css/) for side-by-side comparisons of old and new techniques.

### 1:30 — Bridge to design reviews

> "Every pair started from the **same HTML** and ended up with very different results. Now imagine each of those landed as a PR with no agreed design. Which one do we merge? How much rework did we just create?"

Then start the design review segment.

---

## Cheat sheet

**Selectors**

| Syntax | Meaning |
|---|---|
| `h3` | type |
| `.card` | class |
| `#roster` | id |
| `[data-status=sleeping]` | attribute |
| `a b` | `b` anywhere inside `a` |
| `a > b` | `b` that is a direct child of `a` |
| `a + b` | `b` immediately after `a` |
| `a ~ b` | `b` anywhere after `a`, among its siblings |
| `.a.b` | has both `a` and `b` (AND) |
| `.a, .b` | either one (OR) |
| `:hover` `:focus` | interaction state |
| `:first-child` `:nth-child(2n)` | position |
| `:not(x)` | doesn't match `x` |
| `:has(x)` | contains `x` |
| `:is(a, b) c` | shorthand for `a c, b c` |
| `:nth-child(2n of .card)` | count only siblings that match `.card` |
| `:focus-visible` | keyboard focus (not mouse clicks) |

**Specificity:** (IDs . classes/attributes/pseudo-classes . elements). The higher number wins. On a tie, the later rule wins. `!important` beats both. Rules outside an `@layer` beat rules inside one, whatever the specificity.

**Modern habits:**

| Instead of | Use |
|---|---|
| Repeating colors for dark mode | `light-dark(light, dark)` + `color-scheme` |
| `transform: translateY() rotate() scale()` | `translate`, `rotate`, `scale` as separate properties |
| `@media (max-width: 560px)` | `@media (width <= 560px)` |
| `:focus` | `:focus-visible` |
| Animations that always run | Add `@media (prefers-reduced-motion: reduce)` |
| Hard-coded `rgb(…/ .6)` tints | `color-mix(in srgb, var(--x) 60%, transparent)` |
| `!important` to win a fight | `@layer` |

**Box model:** content → padding → border → margin. Always set `*, *::before, *::after { box-sizing: border-box; }`.

**Layout:** Flexbox for one dimension: `display:flex; gap; align-items; justify-content`. Grid for two dimensions: `display:grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr))`.

**DevTools console**

| Command | What it does |
|---|---|
| `$0` | the selected element |
| `$$('sel')` | all matches, as an array |
| `getComputedStyle($0).prop` | the value the browser actually applied |
| `document.designMode="on"` | makes the whole page editable |
| Ctrl+Shift+P → "Rendering" | emulate dark mode or print styles |
